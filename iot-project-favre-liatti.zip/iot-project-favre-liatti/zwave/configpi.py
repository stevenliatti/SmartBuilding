name = 'Pi lab1'
location = 'lausanne'
interface = '/dev/ttyACM0'	#/dev/ttyUSB0 ou /dev/ttyAMA0
